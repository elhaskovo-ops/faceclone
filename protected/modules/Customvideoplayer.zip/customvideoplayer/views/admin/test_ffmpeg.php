<?php
use yii\helpers\Html;
?>

<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">FFmpeg Test Results</h4>
        </div>
        <div class="modal-body">
            <div class="alert alert-<?= $ffmpegWorking ? 'success' : 'danger' ?>">
                <strong>FFmpeg:</strong> 
                <?= $ffmpegWorking ? 'Working correctly' : 'Not found or not working' ?>
            </div>
            
            <div class="alert alert-<?= $ffprobeWorking ? 'success' : 'danger' ?>">
                <strong>FFprobe:</strong> 
                <?= $ffprobeWorking ? 'Working correctly' : 'Not found or not working' ?>
            </div>
            
            <?php if (!empty($output)): ?>
            <div class="well">
                <strong>Command Output:</strong><br>
                <pre><?= Html::encode(implode("\n", $output)) ?></pre>
            </div>
            <?php endif; ?>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">
                Close
            </button>
        </div>
    </div>
</div>