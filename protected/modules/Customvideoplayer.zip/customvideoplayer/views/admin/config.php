<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;

\humhub\modules\customvideoplayer\assets\VideoPlayerAssets::register($this);
?>

<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading">
            <strong><?= Yii::t('customvideoplayer', 'Custom Video Player Settings') ?></strong>
        </div>
        
        <div class="panel-body">
            <div class="alert alert-info">
                <strong><?= Yii::t('customvideoplayer', 'Information') ?>:</strong><br>
                <?= Yii::t('customvideoplayer', 'This module replaces the default HumHub video player with an advanced adaptive video player.') ?>
            </div>

            <?php $form = ActiveForm::begin(['id' => 'configure-form']); ?>
            
            <div class="row">
                <div class="col-md-6">
                    <h4><?= Yii::t('customvideoplayer', 'FFmpeg Settings') ?></h4>
                    
                    <?= $form->field($model, 'ffmpegPath')->textInput([
                        'placeholder' => 'ffmpeg'
                    ]) ?>
                    
                    <?= $form->field($model, 'ffprobePath')->textInput([
                        'placeholder' => 'ffprobe'
                    ]) ?>
                    
                    <?= $form->field($model, 'maxVideoSize')->textInput([
                        'type' => 'number',
                        'min' => 1,
                        'max' => 2048
                    ]) ?>
                    
                    <?= $form->field($model, 'allowedFormats')->textInput([
                        'placeholder' => 'mp4,avi,mov,mkv,webm'
                    ]) ?>
                </div>
                
                <div class="col-md-6">
                    <h4><?= Yii::t('customvideoplayer', 'Player Features') ?></h4>
                    
                    <?= $form->field($model, 'enableAdaptiveQuality')->checkbox([
                        'label' => Yii::t('customvideoplayer', 'Enable automatic quality adjustment based on network speed')
                    ]) ?>
                    
                    <?= $form->field($model, 'enableSubtitles')->checkbox([
                        'label' => Yii::t('customvideoplayer', 'Enable subtitle support')
                    ]) ?>
                    
                    <?= $form->field($model, 'enablePictureInPicture')->checkbox([
                        'label' => Yii::t('customvideoplayer', 'Enable Picture-in-Picture mode')
                    ]) ?>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <hr>
                    <div class="form-group">
                        <?= Html::submitButton(
                            Yii::t('customvideoplayer', 'Save Settings'), 
                            ['class' => 'btn btn-primary', 'name' => 'save-button']
                        ) ?>
                        
                        <?= Html::a(
                            Yii::t('customvideoplayer', 'Test FFmpeg'), 
                            ['/customvideoplayer/admin/test-ffmpeg'],
                            ['class' => 'btn btn-info', 'target' => '_blank']
                        ) ?>
                    </div>
                </div>
            </div>
            
            <?php ActiveForm::end(); ?>
        </div>
    </div>
    
    <!-- System Information -->
    <div class="panel panel-default">
        <div class="panel-heading">
            <strong><?= Yii::t('customvideoplayer', 'System Information') ?></strong>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <tr>
                            <th><?= Yii::t('customvideoplayer', 'PHP Version') ?></th>
                            <td><?= PHP_VERSION ?></td>
                        </tr>
                        <tr>
                            <th><?= Yii::t('customvideoplayer', 'FFmpeg Available') ?></th>
                            <td>
                                <?php
                                $ffmpegAvailable = shell_exec('which ' . escapeshellarg($model->ffmpegPath ?: 'ffmpeg'));
                                echo $ffmpegAvailable ? 
                                    '<span class="label label-success">' . Yii::t('customvideoplayer', 'Yes') . '</span>' : 
                                    '<span class="label label-danger">' . Yii::t('customvideoplayer', 'No') . '</span>';
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?= Yii::t('customvideoplayer', 'FFprobe Available') ?></th>
                            <td>
                                <?php
                                $ffprobeAvailable = shell_exec('which ' . escapeshellarg($model->ffprobePath ?: 'ffprobe'));
                                echo $ffprobeAvailable ? 
                                    '<span class="label label-success">' . Yii::t('customvideoplayer', 'Yes') . '</span>' : 
                                    '<span class="label label-danger">' . Yii::t('customvideoplayer', 'No') . '</span>';
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>